---
name: zoom-out
description: Tell the agent to zoom out and give broader context or a higher-level perspective. Use when you're unfamiliar with a section of code or need to understand how it fits into the bigger picture.
disable-model-invocation: true
metadata:
  upstream: https://github.com/mattpocock/skills/blob/main/skills/engineering/zoom-out/SKILL.md
  imported_at: "2026-05-23"
portable: false
compatibility:
  - claude-code
---

I don't know this area of code well. Go up a layer of abstraction. Give me a map of all the relevant modules and callers, using the project's domain glossary vocabulary.
